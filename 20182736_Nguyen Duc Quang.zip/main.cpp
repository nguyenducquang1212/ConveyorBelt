// #include <wiringPi.h>
#include "Conveyor.h"



int main(int argc, char const *argv[])
{



    Conveyor conveyor;

    // for (int i = 0; i < NUM_TEST; i++)
    // {
    //     std::cout << "(TYPE) " << randomType()  <<  ", ";
    // }
        
    conveyor.run();

    
    return 0;
}
